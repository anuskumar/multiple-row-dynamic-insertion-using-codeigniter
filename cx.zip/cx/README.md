# codeigniter-add-remove-multiple-input-fields-jquery
Codeigniter Add Remove Input Fields Dynamically with Jquery and submit to database
